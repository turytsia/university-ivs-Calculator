## Prostredi
Windows 64bit

## Autori

Tripple-Double
- xbuten00 Pavlo Butenko
- xkolia00 Nikita Koliada
- xpodho08 Maksym Podhornyi
- xturyt00 Oleksandr Turytsia

## Licence

Tento program je poskytovan GNU GPL v. 3
